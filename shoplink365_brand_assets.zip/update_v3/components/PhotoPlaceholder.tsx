import Image from "next/image";
import { withBase } from "@/lib/basePath";

export default function PhotoPlaceholder({
  className = "",
}: {
  className?: string;
}) {
  return (
    <div
      className={`bg-[#EEE8DB] flex items-center justify-center relative ${className}`}
    >
      <Image
        src={withBase("/brand/watermark.png")}
        alt=""
        width={48}
        height={48}
        className="opacity-25"
      />
    </div>
  );
}
